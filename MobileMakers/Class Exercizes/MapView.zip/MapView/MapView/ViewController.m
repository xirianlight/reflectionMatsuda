//
//  ViewController.m
//  MapView
//
//  Created by Don Bora on 2/25/13.
//  Copyright (c) 2013 Don Bora. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>
#import "Annotation.h"

@interface ViewController ()
{
    IBOutlet MKMapView *myMapView;
}
@end

@implementation ViewController

- (void)viewDidLoad
{

    [super viewDidLoad];
    
    CLLocationCoordinate2D mmCoordinate =
    {
        .latitude = 41.894032f,
       .longitude = -87.634742f
    };
    
    //mmCoordinate.latitude = 41.894032f;
    //mmCoordinate.longitude = -87.634742f;
    
    
    MKCoordinateSpan span =
    {
         .latitudeDelta = 0.002f,
        .longitudeDelta = 0.002f
    };
    
    MKCoordinateRegion myRegion = {mmCoordinate, span};
    
    Annotation *myAnnnotation = [[Annotation alloc] init];
    myAnnnotation.title = @"MobileMakers";
    myAnnnotation.coordinate = mmCoordinate;
    myAnnnotation.subtitle = @"subtitles";
    
    [myMapView setRegion:myRegion];
    [myMapView addAnnotation:myAnnnotation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showDetail
{
    NSLog(@"Striker rules");
}

-(MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    UIButton *detailButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    MKAnnotationView *annotationView = [mapView dequeueReusableAnnotationViewWithIdentifier:@"myAnnotation"];
    
    if (annotationView == nil) {
        annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"myAnnotation"];
    }
    
    [detailButton addTarget:self
                     action:@selector(showDetail)
           forControlEvents:UIControlEventTouchUpInside];
    //pinView.pinColor = MKAnnotationColorPurple;
    annotationView.canShowCallout = YES;
    annotationView.image = [UIImage imageNamed:@"mobile-makers-logo.png"];
    annotationView.rightCalloutAccessoryView = detailButton;
    
    return annotationView;
}
@end







